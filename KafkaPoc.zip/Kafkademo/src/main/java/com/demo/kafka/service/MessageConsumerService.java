package com.demo.kafka.service;

import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.demo.kafka.model.UserModel;

@EnableKafka
@Service
public class MessageConsumerService {

//	@KafkaListener(topics = "${kafka.topic.sample}", groupId = "${kafka.groupid}")
//	public void sampleKafkaConsumer(String message) {
//		System.out.println("Consumer Message : " + message);
//	}
//
//	@KafkaListener(topics = "${kafka.topic.user}", groupId = "${kafka.groupid}", containerFactory = "userKafkaListenerContainerFactory")
//	public void userKafkaConsumer(UserModel message) {
//		System.out.println("Consumer Message : " + message.toString());
//	}

}

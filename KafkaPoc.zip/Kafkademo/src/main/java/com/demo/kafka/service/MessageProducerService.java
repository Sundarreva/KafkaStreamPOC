package com.demo.kafka.service;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import com.demo.kafka.constant.KafkaConfigProp;
import com.demo.kafka.model.UserModel;
import com.demo.kafka.utils.CommonBuilderUtils;

@Service
public class MessageProducerService {

	@Autowired
	private KafkaTemplate<String, String> sampleKafkaTemplate;

	@Autowired
	private KafkaTemplate<String, UserModel> userKafkaTemplate;

	@Autowired
	private KafkaConfigProp config;
	
	@Autowired
	private CommonBuilderUtils builderUtils;

	public String publishToSampleKafka(String msg) throws InterruptedException, ExecutionException {
		SendResult<String, String> result = sampleKafkaTemplate.send(config.getSampleTopic(), "first", msg).get();
		return result.toString();
	}

	public String publishToUserKafka(String name) throws InterruptedException, ExecutionException {
		UserModel user = builderUtils.buildUser(name);
		SendResult<String, UserModel> result = userKafkaTemplate.send(config.getUserTopic(), user.getUserId(), user).get();
		return result.toString();
	}

}

package com.demo.stream.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.serialization.StringSerializer;

public class KafkaProducerTest {

	public static void main(String[] args) {
		KafkaConfigProp config = new KafkaConfigProp();
		Map<String, Object> props = new HashMap<>();
		
		props.put(ProducerConfig.CLIENT_ID_CONFIG, "test");
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        
        KafkaProducer<String, String> producer = new KafkaProducer<>(props);
        
        try {
            for (int i = 1; i <= 3; i++) {
                producer.send(new ProducerRecord<>("SampleKafka", i+"", "Message-" + i));
            }
        } catch (KafkaException e) {
        	System.out.println("----------------- Kafka error");
            System.exit(-1);
        } finally {
            producer.close();
        }

		

	}

}

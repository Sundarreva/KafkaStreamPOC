package com.demo.kafka.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.demo.kafka.constant.KafkaConfigProp;

@Configuration
public class KafkaTopicConfig {

	@Autowired
	private KafkaConfigProp config;

//	@Bean
//	public KafkaAdmin kafkaAdmin() {
//
//		Map<String, Object> configs = new HashMap<>();
//		configs.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, config.getBootstrapAddress());
//		return new KafkaAdmin(configs);
//	}

//	@Bean
//	public NewTopic topic1() {
//		return new NewTopic(config.getSampleTopic(), 1, (short) 1);
//	}
	
	//create new topic without kafka Admin
//	@Bean
//	public NewTopic topic2() {
//		return TopicBuilder.name("TestTopic").partitions(1).replicas(1).build();
//	}

}

package com.demo.kafka.controller;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.kafka.constant.KafkaConfigProp;
import com.demo.kafka.service.MessageProducerService;

@RestController
@RequestMapping("/msg")
public class MessengerController {

	@Autowired
	private MessageProducerService producerService;

	@Autowired
	private KafkaConfigProp config;

	@PostMapping("/publish")
	public String sendMessageToSample(@RequestParam(required = true) String msg)
			throws InterruptedException, ExecutionException {
		
		producerService.publishToSampleKafka(msg);
		return "Message pushed to " + config.getSampleTopic();
	}
	
	@PostMapping("/userpublish")
	public String sendMessageToUser(@RequestParam(required = true) String name)
			throws InterruptedException, ExecutionException {
		
		producerService.publishToUserKafka(name);
//		return producerService.publishToUserKafka(name);
		return "Message pushed to " + config.getUserTopic();
	}

}

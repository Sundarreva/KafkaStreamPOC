package com.demo.kafka.service;

import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.demo.kafka.model.UserModel;

@EnableKafka
@Service
public class MessageConsumerService {

//	@KafkaListener(topics = "${kafka.topic.sample}", groupId = "${kafka.groupid}")
//	public void sampleKafkaConsumer(String message) {
//		System.out.println("Consumer Message : " + message);
//	}
	
	
	// need deserilizer for user model
//	@KafkaListener(topics = "${kafka.topic.user}", groupId = "${kafka.groupid}", containerFactory = "userKafkaListenerContainerFactory")
//	public void userKafkaConsumer(UserModel message) {
//		System.out.println("User Consumer Message : " + message.toString());
//	}

//	@KafkaListener(topics = "${kafka.topic.activeuser}", groupId = "${kafka.groupid}", containerFactory = "activeUserKafkaListenerContainerFactory")
//	public void activeUserKafkaConsumer(UserModel message) {
//		System.out.println("Active User Consumer Message : " + message.toString());
//	}

}

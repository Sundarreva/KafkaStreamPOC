package com.demo.kafka.utils;

import org.springframework.stereotype.Component;

import com.demo.kafka.model.UserModel;

@Component
public class CommonBuilderUtils {
	
		public UserModel buildUser(String name) {
			UserModel user = new UserModel();
			user.setUserId(randomGenerate() + "");
			user.setRole("test");
			user.setUserName(name);
			user.setStatus((randomGenerate() % 2 == 0) ? true : false);
			System.out.println("Generated : "+user.toString());
			return user;
		}

		public int randomGenerate() {
			return (int) (Math.random() * (200)) + 200;
		}

}

package com.demo.stream.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class KafkaConfigProp {

	@Value(value = "${kafka.topic.activeuser}")
	private String activeUser;
	
	@Value(value = "${kafka.topic.user}")
	private String userTopic;

	@Value(value = "${kafka.bootstrapaddress}")
	private String bootstrapAddress;

	@Value(value = "${kafka.groupid}")
	private String groupId;

}

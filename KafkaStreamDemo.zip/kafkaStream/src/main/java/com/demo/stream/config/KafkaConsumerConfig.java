package com.demo.stream.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.adapter.RecordFilterStrategy;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import com.demo.stream.model.UserModel;
import com.demo.stream.serdes.CustomSerdes;

@EnableKafka
@Configuration
public class KafkaConsumerConfig {

	@Autowired
	private KafkaConfigProp config;

	// User Kafka
	@Bean
	public ConsumerFactory<String, UserModel> userConsumerFactory() {
		Map<String, Object> props = new HashMap<>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getBootstrapAddress());
		props.put(ConsumerConfig.GROUP_ID_CONFIG, config.getGroupId());
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
//		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);

		return new DefaultKafkaConsumerFactory<>(props);
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, UserModel> userKafkaListenerContainerFactory() {

		ConcurrentKafkaListenerContainerFactory<String, UserModel> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(userConsumerFactory());
//        factory.setAckDiscarded(true);
//        factory.setRecordFilterStrategy(new RecordFilterStrategy<String, UserModel>() {
//            @Override
//            public boolean filter(ConsumerRecord<String, UserModel> consumerRecord) {
//            	UserModel user = consumerRecord.value();
//                if (user != null) {
//                    return false;
//                }
//                //Return true will be discarded
//                return true;
//            }
//        });
		return factory;
	}

//	ActiveUser Consumer bean
	@Bean
	public ConsumerFactory<String, UserModel> activeUserConsumerFactory() {
		Map<String, Object> props = new HashMap<>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getBootstrapAddress());
		props.put(ConsumerConfig.GROUP_ID_CONFIG, config.getGroupId());
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);

		return new DefaultKafkaConsumerFactory<>(props);
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, UserModel> activeUserKafkaListenerContainerFactory() {

		ConcurrentKafkaListenerContainerFactory<String, UserModel> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(activeUserConsumerFactory());
		factory.setAckDiscarded(true);
		factory.setRecordFilterStrategy(new RecordFilterStrategy<String, UserModel>() {
			@Override
			public boolean filter(ConsumerRecord<String, UserModel> consumerRecord) {
				if (consumerRecord.value() != null) {
					return false;
				}
				// Return true will be discarded
				return true;
			}
		});
		return factory;
	}

}

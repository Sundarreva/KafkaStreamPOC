package com.demo.stream.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.EnableKafkaStreams;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerde;

import com.demo.stream.model.UserModel;
import com.demo.stream.serdes.CustomSerdes;

@Configuration
@EnableKafka
@EnableKafkaStreams
public class KafkaStreamConfig {

	@Autowired
	private KafkaConfigProp config;
	
	
//	create sample kafka topic and stream from using below 2 bean
//	@Bean
//	public StreamsConfig sampleKafkaKStreamsConfigs() {
//		Map<String, Object> props = new HashMap<>();
//		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "test");
//		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, config.getBootstrapAddress());
//		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
//		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
//		props.put(JsonDeserializer.KEY_DEFAULT_TYPE, String.class);
//		props.put(JsonDeserializer.VALUE_DEFAULT_TYPE, String.class);
//		return new StreamsConfig(props);
//	}
//
//	@Bean
//	public KStream<String, String> kStreamString(StreamsBuilder builder) {
//		KStream<String, String> stream = builder.stream("userkafka",
//				Consumed.with(Serdes.String(), new Serdes.StringSerde()));
//		stream.foreach((k, v) -> System.out.println(k + ": " + v));
//		KTable<String, String> combinedDocuments = 	stream.toTable().mapValues(n -> String.valueOf(n));
//		combinedDocuments.toStream().to("SampleKafka", Produced.with(Serdes.String(), new Serdes.StringSerde()));
//		return stream;
//	}

	@Bean
	public StreamsConfig kStreamsConfigs() {
		Map<String, Object> props = new HashMap<>();
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "userTest");
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, config.getBootstrapAddress());
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, new JsonSerde<>(UserModel.class).getClass());
		props.put(JsonDeserializer.KEY_DEFAULT_TYPE, String.class);
		props.put(JsonDeserializer.VALUE_DEFAULT_TYPE, UserModel.class);
		return new StreamsConfig(props);
	}

	@Bean
	public KStream<String, UserModel> kStreamJson(StreamsBuilder builder) {
		KStream<String, UserModel> stream = builder.stream(config.getUserTopic(),
				Consumed.with(Serdes.String(), CustomSerdes.UserModel()));
		
		stream.foreach((k, v) -> System.out.println(k + ": " + v.toString()));

		KTable<String, UserModel> combinedDocuments = stream.toTable()
		.filter((k, v) -> v.isStatus());

		combinedDocuments.toStream().to(config.getActiveUser(),
				Produced.with(Serdes.String(), CustomSerdes.UserModel())); 
		return stream;
	}

}

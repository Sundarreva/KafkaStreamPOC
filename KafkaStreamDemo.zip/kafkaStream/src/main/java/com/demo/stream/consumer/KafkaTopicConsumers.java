package com.demo.stream.consumer;

import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.demo.stream.model.UserModel;

@EnableKafka
@Service
public class KafkaTopicConsumers {
	
	@KafkaListener(topics = "${kafka.topic.user}", groupId = "${kafka.groupid}", containerFactory = "userKafkaListenerContainerFactory")
	public void userKafkaConsumer(@Payload String message, 
			@Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.RECEIVED_MESSAGE_KEY) Integer key,
            @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
            @Header(KafkaHeaders.OFFSET) String offset) {
		System.out.println("User Consumer Message : " + message.toString());
	}	
	
	@KafkaListener(topics = "${kafka.topic.activeuser}", groupId = "${kafka.groupid}", containerFactory = "activeUserKafkaListenerContainerFactory")
	public void activeUserKafkaConsumer(@Payload String message, 
			@Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.RECEIVED_MESSAGE_KEY) Integer key,
            @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
            @Header(KafkaHeaders.OFFSET) String offset) {
		System.out.println("Active User Consumer Message : " + message.toString());
	}

}

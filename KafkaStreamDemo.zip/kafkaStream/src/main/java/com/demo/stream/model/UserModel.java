package com.demo.stream.model;

import lombok.Data;

@Data
public class UserModel {
	
	private String userId;
	private String userName;
	private String role;
	private boolean status;

}

package com.demo.stream.serdes;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;

import com.demo.stream.model.UserModel;

public final class CustomSerdes {

//	static public final class BookSoldSerde extends Serdes.WrapperSerde<BookSold> {
//		public BookSoldSerde() {
//			super(new JsonSerializer<>(), new JsonDeserializer<>(BookSold.class));
//		}
//	}

	static public final class UserModelSerde extends Serdes.WrapperSerde<UserModel> {
		public UserModelSerde() {
			super(new JsonSerializer<>(), new JsonDeserializer<>(UserModel.class));
		}
	}

//	public static Serde<BookSold> BookSold() {
//		return new CustomSerdes.BookSoldSerde();
//	}

	public static Serde<UserModel> UserModel() {
		return new CustomSerdes.UserModelSerde();
	}

}
